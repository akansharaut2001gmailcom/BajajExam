package com.demo.app;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;

public class StringGenerator {

	public static void main(String[] args) {
		
		String prnNumber = args[0];
		String jsonFilePath = args[1];
		
		try {
			String jsonContents = new String(Files.readAllBytes(Paths.get(jsonFilePath)));
			
			JSONObject jobject = new JSONObject(jsonContents);
			
			String destination = findDestinationValue(jobject);
			
			if(destination==null) {
				System.out.println("Destination Value Not Found");
				return;
			}
			
			
			
			String generateNewRandomString = generateRandomString(8);
			
			String concatenatedString = prnNumber+destination+generateNewRandomString;
			
			System.out.println(concatenatedString);
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	private static String generateRandomString(int length) {
		
		
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		Random random = new Random();
		StringBuilder sbuilder = new StringBuilder();
		
		for(int i=0;i<length ;i++) {
			int index = random.nextInt(chars.length());
			sbuilder.append(chars.charAt(index));
		}
		return sbuilder.toString();
	}

	private static String findDestinationValue(JSONObject jobject) {
		// TODO Auto-generated method stub
		Queue<Object> queue = new LinkedList<>();
		queue.add(jobject);
		
		while(!queue.isEmpty()) {
			Object current = queue.poll();
			if(current instanceof JSONObject) {
				JSONObject jsonObject = (JSONObject) current;
				
				if(jsonObject.has("destination")) {
					return jsonObject.getString("destination");
				}
				
				for(String key : jsonObject.keySet()) {
					queue.add(jsonObject.get(key));
				}
			}else if(current instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray) current;
				
				for(int i=0;i<jsonArray.length();i++) {
					queue.add(jsonArray.get(i));
				}
			}
		}
		return null;
	}

}
